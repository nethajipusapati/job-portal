import React from "react";

export default function Footer() {
  return (
    <div className="flex-initial flex text-black justify-center">
      <div className="w-3/6 p-3 bg-blue-100 shadow text-center">
        Jacob John Jeevan
      </div>
    </div>
  );
}
