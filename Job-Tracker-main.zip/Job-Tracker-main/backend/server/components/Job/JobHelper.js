const addDefaultUser = (req, res, next) => {};

const validateToken = (req, res, next) => {};

const addUserToRequest = (userId) => {};

module.exports = {
  addDefaultUser,
  validateToken,
  addUserToRequest,
};
